﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Trees
{
    class BinarySearchTree
    {
        public Node Root;

        public void Insert(int value)
        {
            Root = InsertRecursive(Root, value);
        }

        private Node InsertRecursive(Node current, int value)
        {
            if (current == null)
                return new Node(value);

            if (value < current.Value)
                current.Left = InsertRecursive(current.Left, value);
            else if (value > current.Value)
                current.Right = InsertRecursive(current.Right, value);

            return current;
        }

        public bool Search(int value)
        {
            return SearchRecursive(Root, value);
        }

        private bool SearchRecursive(Node current, int value)
        {
            if (current == null)
                return false;

            if (value == current.Value)
                return true;

            if (value < current.Value)
                return SearchRecursive(current.Left, value);

            return SearchRecursive(current.Right, value);
        }

        public void InOrderTraversal()
        {
            InOrderRecursive(Root);
            Console.WriteLine();
        }

        private void InOrderRecursive(Node current)
        {
            if (current != null)
            {
                InOrderRecursive(current.Left);
                Console.Write(current.Value + " ");
                InOrderRecursive(current.Right);
            }
        }
    }

}

﻿namespace Trees
{
    class Program
    {
        static void Menu()
        {
            Console.WriteLine("\n1. Добавяне на елемент");
            Console.WriteLine("2. Търсене на елемент");
            Console.WriteLine("3. Обхождане (In-order)");
            Console.WriteLine("4. Изход");
        }

        static void Main()
        {
            BinarySearchTree tree = new BinarySearchTree();

            while (true)
            {
                Menu();
                Console.Write("Избор: ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        Console.Write("Въведи число: ");
                        int value = int.Parse(Console.ReadLine());
                        tree.Insert(value);
                        Console.WriteLine("Елементът е добавен.");
                        break;

                    case "2":
                        Console.Write("Въведи число за търсене: ");
                        int search = int.Parse(Console.ReadLine());
                        Console.WriteLine(tree.Search(search)
                        ? "Елементът е намерен."
                        : "Елементът НЕ е намерен.");
                        break;

                    case "3":
                        Console.WriteLine("Обхождане на дървото:");
                        tree.InOrderTraversal();
                        break;

                    case "4":
                        Console.WriteLine("Край на програмата.");
                        return;

                    default:
                        Console.WriteLine("Невалиден избор.");
                        break;
                }
            }
        }
    }
}